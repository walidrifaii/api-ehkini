<?php

namespace App\Http\Controllers\Api\V2;

class FriendshipController extends \App\Http\Controllers\Api\V1\FriendshipController
{
}
