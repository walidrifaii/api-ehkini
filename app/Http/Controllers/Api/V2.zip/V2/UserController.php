<?php

namespace App\Http\Controllers\Api\V2;

class UserController extends \App\Http\Controllers\Api\V1\UserController
{
}
